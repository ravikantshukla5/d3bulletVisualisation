package com.socgen.vo;

import java.io.Serializable;
import java.util.Arrays;

public class BulletVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4615911213813665668L;
	
	private String title;
	private String subtitle;
	private Double [] ranges;
	private Double [] measures;
	private Double [] markers;
	
	public BulletVO() {
		super();
	}
	public BulletVO(String title, String subtitle, Double[] ranges, Double[] measures, Double[] markers) {
		super();
		this.title = title;
		this.subtitle = subtitle;
		this.ranges = ranges;
		this.measures = measures;
		this.markers = markers;
	}



	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubtitle() {
		return subtitle;
	}

	public void setSubtitle(String subtitle) {
		this.subtitle = subtitle;
	}

	public Double[] getRanges() {
		return ranges;
	}
	public void setRanges(Double[] ranges) {
		this.ranges = ranges;
	}
	public Double[] getMeasures() {
		return measures;
	}
	public void setMeasures(Double[] measures) {
		this.measures = measures;
	}
	public Double[] getMarkers() {
		return markers;
	}
	public void setMarkers(Double[] markers) {
		this.markers = markers;
	}
	@Override
	public String toString() {
		return "BulletVO [title=" + title + ", subtitle=" + subtitle + ", ranges=" + Arrays.toString(ranges)
				+ ", measures=" + Arrays.toString(measures) + ", markers=" + Arrays.toString(markers) + "]";
	}
    
}
