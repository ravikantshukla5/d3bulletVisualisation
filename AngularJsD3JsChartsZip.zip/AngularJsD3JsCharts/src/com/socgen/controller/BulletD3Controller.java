package com.socgen.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONArray;

import com.socgen.vo.BulletVO;

/**
 * Servlet implementation class StudentDataController
 */
@WebServlet("/bulletd3Controller")
public class BulletD3Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BulletD3Controller() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<BulletVO> bulletGraph = getStudents();
		response.getWriter().println(new JSONArray(bulletGraph).toString());
	}

	private List<BulletVO> getStudents() {
		List<BulletVO> bullets = new ArrayList<BulletVO>();
		BulletVO blt1 = new BulletVO("Revenue", "US$, in thousands", new Double []{150.0,225.0,300.0}, new Double [] {220.0,270.0}, new Double []{250.0});
		BulletVO blt2 = new BulletVO("Profit", "%", new Double []{20.0,25.0,30.0}, new Double [] {21.0,23.0}, new Double []{26.0});
		BulletVO blt3 = new BulletVO("Order Size", "US$, average", new Double []{350.0,500.0,600.0}, new Double [] {100.0,320.0}, new Double []{550.0});
		BulletVO blt4 = new BulletVO("New Customers", "count", new Double []{1400.0,2000.0,2500.0}, new Double [] {1000.0,1650.0}, new Double []{2100.0});
		BulletVO blt5 = new BulletVO("Satisfaction", "out of 5", new Double []{3.5,4.25,5.0}, new Double [] {3.2,4.7}, new Double []{4.4});
		bullets.add(blt1);
		bullets.add(blt2);
		bullets.add(blt3);
		bullets.add(blt4);
		bullets.add(blt5);
		return bullets;
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
