mainApp.controller("studentController",function($scope){
	$scope.student = {
			firstName : "Ravikant",
			lastName : "Shukla",
			subjects : [{name:'Physics',marks:89},{name:'Math',marks:80},{name:'Chemistry',marks:85}],
			fullName : function(){
				var stdObj;
				stdObj = $scope.student;
				return stdObj.firstName+' '+stdObj.lastName;
			}
	}
});